/*
 * PropertyFileLoader.java
 *
 * June 11, 2020
 *
 * Copyright (c) 2020 Orange
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * AmeriChoice.  You shall use it only in accordance with the terms
 * of the license agreement you entered into with AmeriChoice.
 *
 *
 * DATE        PACKAGE      AUTHOR			DESCRIPTION
 * 06/11/2020  CCR-EDH      Keshavv A       Generic extract to provide based on the provided details.
 */


package com.orange.extract.utility;

import java.io.IOException;
import java.util.Properties;

/**
 * @author kaggarwa
 *
 */
public class PropertyFileLoader extends Properties {

	/**
	 * 
	 */
	private static final long serialVersionUID = -9083999279552535103L;
	
	

	/**
	 * @return the oProps
	 */
	public Properties getOProps() {
		Properties oProps =null;
		try {
			oProps = new Properties();
			oProps.load(this.getClass().getClassLoader().getResourceAsStream("db.properties"));

		} catch (IOException ie) {
			ie.printStackTrace();
			System.exit(1);
		}

		return oProps;
	}

	
	
	

}
