/*
 * DBConnect.java
 *
 * June 11, 2020
 *
 * Copyright (c) 2020 Orange
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * AmeriChoice.  You shall use it only in accordance with the terms
 * of the license agreement you entered into with AmeriChoice.
 *
 *
 * DATE        PACKAGE      AUTHOR			DESCRIPTION
 * 06/11/2020  CCR-EDH      Keshavv A       Generic extract to provide based on the provided details.
 */

package com.orange.extract.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class DBConnect {

	private static Connection conn = null;
	private final static String con="CON_";

	public static Connection getConnection(String dbInstance, String soracle_or_postgresql, String userName, String password)
			throws ClassNotFoundException, SQLException {

		Properties properties = null;
		PropertyFileLoader propertyFileLoader = new PropertyFileLoader();

		if (null == conn) {
			properties = propertyFileLoader.getOProps();
			Class.forName(properties.getProperty(soracle_or_postgresql));
			String[] conString = dbInstance.split(":");
			String conProperties = properties.getProperty(con+soracle_or_postgresql);
			String instance = conProperties.replaceAll("vhost", conString[0]).replaceAll("vport", conString[1])
					.replaceAll("vservicename", conString[2]);
			System.out.println("instance : > " + instance);
			conn = DriverManager.getConnection(instance, userName, password);
			System.out.println("Database Connected... ");
			conn.setAutoCommit(false);
		}

		return conn;
	}

	/**
	 * 
	 * @param conn
	 */
	public static void closeConnection(Connection conn) {
		try {
			if (null != conn) {
				conn.close();
			}
		} catch (Exception ignore) {
		}
	}

	/**
	 * 
	 * @param stmt
	 */
	public static void close(Statement stmt) {
		try {
			if (null != stmt) {
				stmt.close();
			}
		} catch (Exception ignore) {

		}
	}

	/**
	 * 
	 * @param rs
	 */
	public static void close(ResultSet rs) {
		try {
			if (null != rs) {
				rs.close();
			}
		} catch (Exception ignore) {
		}
	}

	/**
	 * 
	 * @param ps
	 */
	public static void close(PreparedStatement ps) {
		try {
			if (null != ps) {
				ps.close();
			}
		} catch (Exception ignore) {
		}
	}

	/**
	 * 
	 * @param ps
	 */

	public static void releaseResources(PreparedStatement preparedStatement) throws SQLException {

		try {

			if (null != preparedStatement) {
				preparedStatement.close();
			}
		}

		catch (// SQL
		Exception se) {
			se.printStackTrace();
			throw new SQLException(se.getMessage());
		}
	}

	/**
	 * 
	 * @param statement
	 * @param conn
	 * @throws SQLException
	 */
	public static void releaseResources(Statement statement, Connection conn) throws SQLException {

		try {

			if (null != statement) {
				statement.close();
			}
			if (null != conn) {
				conn.close();
			}
		}

		catch (SQLException se) {
			se.printStackTrace();
			throw new SQLException(se.getMessage());
		}

	}

	/**
	 * 
	 * @param statement
	 * @throws SQLException
	 */
	public static void releaseResources(Statement statement) throws SQLException {

		try {

			if (null != statement) {
				statement.close();
			}
		}

		catch (// SQL
		Exception se) {
			se.printStackTrace();
			throw new SQLException(se.getMessage());
		}
	}

	/**
	 * 
	 * @param rs
	 * @param ps
	 * @param conn
	 * @return
	 */

	public static void releaseResources(ResultSet resultSet, PreparedStatement preparedStatement, Connection conn)
			throws SQLException {

		try {
			if (null != resultSet) {
				resultSet.close();
			}
			if (null != preparedStatement) {
				preparedStatement.close();
			}
			if (null != conn) {
				conn.close();
			}
		}

		catch (SQLException se) {
			se.printStackTrace();
			throw new SQLException(se.getMessage());
		}
	}

	/**
	 * 
	 * @param rs
	 */

	public void releaseResources(ResultSet resultSet) throws SQLException {

		try {

			if (null != resultSet) {
				resultSet.close();
			}
		}

		catch (// SQL
		Exception se) {
			se.printStackTrace();
			throw new SQLException(se.getMessage());
		}
	}

	/**
	 * 
	 * @param rs
	 */
	public void releaseResources(ResultSet resultSet, PreparedStatement preparedStatement) throws SQLException {

		try {
			if (null != resultSet) {
				resultSet.close();
			}

			if (null != preparedStatement) {
				preparedStatement.close();
			}
		}

		catch (// SQL
		Exception se) {
			se.printStackTrace();
			throw new SQLException(se.getMessage());
		}
	}

	/**
	 * 
	 * @param conn
	 */

	public void releaseResources(Connection conn) throws SQLException {

		try {

			if (null != conn) {
				conn.close();
			}
		}

		catch (// SQL
		Exception se) {
			se.printStackTrace();
			throw new SQLException(se.getMessage());
		}
	}

	/**
	 * 
	 * @param conn
	 * @throws SQLException
	 */
	public static void commit(Connection conn) throws SQLException {
		try {

			if (null != conn) {
				conn.commit();
			}
		}

		catch (SQLException se) {
			se.printStackTrace();
			throw new SQLException(se.getMessage());
		}
	}

}
