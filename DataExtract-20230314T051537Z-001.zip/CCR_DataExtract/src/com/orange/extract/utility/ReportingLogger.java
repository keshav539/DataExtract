package com.orange.extract.utility;
/*
 * ReportingLogger.java
 *
 * June 11, 2020
 *
 * Copyright (c) 2020 Orange
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * AmeriChoice.  You shall use it only in accordance with the terms
 * of the license agreement you entered into with AmeriChoice.
 *
 *
 * DATE        PACKAGE      AUTHOR			DESCRIPTION
 * 06/11/2020  CCR-EDH      Keshavv A       Generic extract to provide based on the provided details.
 */
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * This is a logger class to log info / error messages.
 * 
 * @author mgarg1
 * 
 */
public final class ReportingLogger {

	/*
	 * Static final variable to hold the singleton instance of the class
	 */

	private static ReportingLogger singleton = null;
	/*
	 * Instance name of the Logger object
	 */
	private static Logger logs = null;
	
	
	/*
	 * Private Constructor
	 */
	private ReportingLogger() {

	}

	/**
	 * This method returns instance of CSV Loader Logger
	 * 
	 * @param dto
	 * @return
	 */
	public static ReportingLogger getLogInstance(String slogLocation, String outFilename) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		String logFile = "";
		FileHandler fileHandler = null;
		try {

			if (singleton == null) {
				singleton = new ReportingLogger();
				logFile = outFilename + "_" + sdf.format(System.currentTimeMillis()) + ".log";
				fileHandler = new FileHandler(slogLocation + File.separator + logFile);
				fileHandler.setFormatter(new java.util.logging.SimpleFormatter());
				logs = Logger.getLogger(logFile);
				logs.addHandler(fileHandler);

			}
		} catch (SecurityException e) {
			logs.log(Level.SEVERE, "Logger Not intialized. " + e.getMessage());

		} catch (IOException e) {
			logs.log(Level.SEVERE, "Logger Not intialized. " + e.getMessage());
			e.printStackTrace();

		}
		return singleton;

	}

	/**
	 * log is the method called from the different class to log the message
	 * 
	 * @param String containing the log message
	 */
	public void log(Level oLogLevel, String strMessage) {
		logs.log(oLogLevel, strMessage);
	}

	/**
	 * log is the method called from the different class to log the message
	 * 
	 * @param String containing the log message
	 */
	public void error(Exception ex) {

		logs.log(Level.SEVERE, ex.getMessage());
	}
	
	

}
