package com.orange.extract.main;

/*
 * RStoFile.java
 *
 * June 11, 2020
 *
 * Copyright (c) 2020 Orange
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * AmeriChoice.  You shall use it only in accordance with the terms
 * of the license agreement you entered into with AmeriChoice.
 *
 *
 * DATE        PACKAGE      AUTHOR			DESCRIPTION
 * 06/11/2020  CCR-EDH      Keshavv A       Generic extract to provide based on the provided details.
 */
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;

import com.orange.extract.utility.DBConnect;
import com.orange.extract.utility.ReportingLogger;

import oracle.jdbc.OracleTypes;

public class RStoFile {

	String soutFilename;
	String slogLocation;
	String sfileLocation;
	String scolumnDelimeter;
	String stextDelimeter;
	String snewLineReplacer;
	String sdbSever;
	String soracle_or_postgresql;
	String suser;
	String spassword;
	String sselectQuery;
	String sfromQuery;
	String swhereQuery;
	String sisHeader;
	final String ext = ".dat";
	final String space = " ";
	final String SELECT = "SELECT";
	final String FROM = "FROM";
	final String WHERE = "WHERE";
	final String DEFAULT_WHERE = " WHERE 1=1 ";
	boolean isLineReplacer = false;
	String sdbproc;
	String sparmExcludeRef;
	boolean isProc = false;
	ReportingLogger logger;

	public RStoFile(String soutFilename, String slogLocation, String sfileLocation, String scolumnDelimeter,
			String stextDelimeter, String snewLineReplacer, String sdbSever, String soracle_or_postgresql, String suser,
			String spassword, String sselectQuery, String sfromQuery, String swhereQuery, String sdbproc,
			String sparmExcludeRef,
			String sisHeader) {

		this.soutFilename = soutFilename;
		this.slogLocation = slogLocation;
		this.sfileLocation = sfileLocation;
		this.scolumnDelimeter = scolumnDelimeter;
		this.stextDelimeter = stextDelimeter;
		this.snewLineReplacer = snewLineReplacer;
		this.sdbSever = sdbSever;
		this.soracle_or_postgresql = soracle_or_postgresql;
		this.suser = suser;
		this.spassword = spassword;
		this.sselectQuery = sselectQuery;
		this.sfromQuery = sfromQuery;
		this.swhereQuery = swhereQuery;
		this.sparmExcludeRef = sparmExcludeRef;
		this.sdbproc = sdbproc;
		this.sisHeader=sisHeader;

		this.logger = ReportingLogger.getLogInstance(slogLocation, soutFilename);

	}

	private void writeHeaderFirst(ResultSetMetaData rsmd, int columnCount, BufferedWriter writer)
			throws IOException, SQLException {

		for (int i = 1; i <= columnCount; i++) {
			writer.write(stextDelimeter + rsmd.getColumnName(i) + stextDelimeter);
			if (i != columnCount) {
				writer.write(scolumnDelimeter);
			}
		}
		// writer.write(stextDelimeter);
		writer.newLine();
		writer.flush();
		logger.log(Level.INFO, "File header is printed.. ");

	}

	public void start() throws ClassNotFoundException, SQLException, IOException {
		FileWriter fw = null;
		Connection con = null;

		try {
			DateFormat df = new SimpleDateFormat("_yyyyMMdd");
			Date dateobj = new Date();
			String timestamp = df.format(dateobj).toString();

			logger.log(Level.INFO, "File writing process is started. .. ");
			File outfile = new File(sfileLocation + File.separator + soutFilename + timestamp + ext);
			if (outfile.exists()) {
				logger.log(Level.INFO, "File already exists. please delete the file first to generate new file..");
				throw new IOException("File already exists ...");
			} else {
				outfile.createNewFile();
			}

			fw = new FileWriter(outfile);
			BufferedWriter writer = new BufferedWriter(fw);
			con = DBConnect.getConnection(sdbSever, soracle_or_postgresql, suser, spassword);
			logger.log(Level.INFO, "Database connected... ");
			ResultSet rs = getResultSet(con);
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			if (sisHeader.equalsIgnoreCase("YES")) {
				writeHeaderFirst(rsmd, columnCount, writer);
			}
			int i = 1;
			while (rs.next()) {
				try {
					for (i = 1; i <= columnCount; i++) {
						Object value = rs.getObject(i);
						if (value == null) {
							writer.write(stextDelimeter + stextDelimeter);
						} else {
							if (!isLineReplacer) {
								writer.write(stextDelimeter + rs.getObject(i).toString() + stextDelimeter);
							} else {
								writer.write(
										stextDelimeter
												+ rs.getObject(i).toString().replaceAll(
														System.getProperty("line.separator"), snewLineReplacer)
												+ stextDelimeter);
							}
						}

						if (i != columnCount) {
							writer.append(scolumnDelimeter);
						}
					}
				} catch (Exception e) {
					logger.log(Level.INFO, "Exception occured at record count  " + i);
					con.close();
					throw e;

				}
				writer.newLine();

			}
			writer.flush();
			writer.close();
			fw.close();
			rs.close();
			con.close();

			logger.log(Level.INFO, "File print process is completed. ");
		} catch (Exception e) {
			logger.log(Level.INFO, "Exception in start process : -> " + e.getMessage());
			throw e;
		} finally {
			fw.close();
			con.close();
		}

	}

	private ResultSet getResultSet(Connection con) throws SQLException {

		if (isProc) {
			String qsym = "?";
			String queryS = "";
			String[] paramArray = null;
			int len = 0;
			if (sparmExcludeRef.trim().length() == 0) {
				queryS = "?";
			} else {
				paramArray = this.sparmExcludeRef.split(",");
				for (int i = 0; i <= paramArray.length; i++) {
					queryS = queryS + "?";
					if (i != paramArray.length) {
						queryS = queryS + ",";
					}
				}
				len = paramArray.length;
			}

			logger.log(Level.INFO, "{ call " + this.sdbproc + "(" + queryS + ") } ");
			CallableStatement cstmt = con.prepareCall("{ call " + this.sdbproc + "(" + queryS + ") } ");

			for (int i = 0; i < len; i++) {
				cstmt.setInt(i + 1, Integer.valueOf(paramArray[i]));
			}

			if (this.soracle_or_postgresql.equals("ORACLE")) {
				cstmt.registerOutParameter(len + 1, OracleTypes.CURSOR);
			} else {
				cstmt.registerOutParameter(len + 1, Types.REF_CURSOR);
			}
			cstmt.execute();

			return cstmt.getObject(len + 1, ResultSet.class);
		}

		else {
			logger.log(Level.INFO, "SQL query " + sselectQuery + space + sfromQuery + space + swhereQuery);
			Statement ps = con.createStatement();
			return ps.executeQuery(sselectQuery + space + sfromQuery + space + swhereQuery);
		}

	}

	public RStoFile inputValidate() throws Exception {
		StringBuffer message = new StringBuffer();
		if ((this.soutFilename).trim().length() == 0) {
			logger.log(Level.INFO, "Out filename cannot be blank....");
			message.append("Out filename cannot be blank.... \n");
		}

		if ((this.slogLocation).trim().length() == 0) {
			logger.log(Level.INFO, "logfile location cannot be blank....");
			message.append("logfile location cannot be blank....\n");
		}

		if ((this.sfileLocation).trim().length() == 0) {
			logger.log(Level.INFO, "File  location cannot be blank....");
			message.append("File location cannot be blank....\n");
		}

		if ((this.scolumnDelimeter).trim().length() == 0) {
			logger.log(Level.INFO, "Column delimeter is required. ....");
			message.append("Column delimeter is required. ....\n");
		}
		if ((this.snewLineReplacer).trim().length() != 0) {
			isLineReplacer = true;
		}

		if ((this.sdbSever).trim().length() == 0) {
			logger.log(Level.INFO, "DB server  is required. ....");
			message.append("DB server is required. ....\n");
		}

		if ((this.soracle_or_postgresql).length() == 0) {
			logger.log(Level.INFO, "DB server type  is required either ORACLE or POSTGRESQL");
			message.append("DB server type  is required either ORACLE or POSTGRESQL...\n");
		}

		if ((this.suser).trim().length() == 0) {
			logger.log(Level.INFO, "User is requierd to connect to the database.. ....");
			message.append("User is requierd to connect to the database ....\n");
		}
		if (!(this.sisHeader.equalsIgnoreCase("NO") || this.sisHeader.equalsIgnoreCase("YES"))) {
			logger.log(Level.INFO, "isHeader parameter should be YES or NO.. ....");
			message.append("isHeader parameter should be YES or NO ....\n");
		}
		
		if (message.length() > 1)
			throw new Exception(message.toString());

		return this;

	}

	public RStoFile QueryCheck() throws Exception {
		StringBuffer message = new StringBuffer();

		if ((this.sselectQuery).trim().length() == 0 && (this.sdbproc).trim().length() > 0) {
			isProc = true;
		}

		else if ((this.sselectQuery).trim().length() == 0 && (this.sdbproc).trim().length() == 0) {
			logger.log(Level.INFO, "Select query and db-proc details  not found . ");
			message.append("Select query and db-proc details  not found . . \n");
		}

		else if ((this.sselectQuery).trim().length() > 0 && (this.sdbproc).trim().length() > 0) {
			logger.log(Level.INFO, "Select query and db-proc details  not found . ");
			message.append("Both Select query and db-proc details found . . \n");
		}

		if (!isProc) {

			if ((this.sselectQuery).trim().length() == 0) {
				logger.log(Level.INFO, "Select query not found . ");
				message.append("Select query not found . \n");
			} else if (!(this.sselectQuery).toUpperCase().trim().startsWith(this.SELECT)) {
				this.sselectQuery = this.SELECT + this.space + this.sselectQuery;
			}

			if ((this.sfromQuery).trim().length() == 0) {
				logger.log(Level.INFO, "from query part not found . ");
				message.append("from query part not found. \n");
			} else if (!(this.sfromQuery).toUpperCase().trim().startsWith(this.FROM)) {
				this.sfromQuery = this.FROM + this.space + this.sfromQuery;
			}

			if ((this.swhereQuery).trim().length() == 0) {
				this.swhereQuery = this.DEFAULT_WHERE;
			} else if (!(this.swhereQuery).toUpperCase().trim().startsWith(this.WHERE)) {
				this.swhereQuery = this.WHERE + this.space + this.swhereQuery;
			}

		}

		else {
			if ((this.sdbproc).trim().length() == 0) {
				logger.log(Level.INFO, "db proc not found . ");
				message.append("db proc not found. \n");
			}

			/*
			 * if ((this.sparmExcludeRef).trim().length() == 0) { logger.log(Level.INFO,
			 * "db proc parameters not found . ");
			 * message.append("db proc parameters not found. \n"); }
			 */
		}

		if (message.length() > 1)
			throw new Exception(message.toString());

		return this;

	}
}
