/*
 * StartProcessMain.java
 *
 * June 11, 2020
 *
 * Copyright (c) 2020 Orange
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * AmeriChoice.  You shall use it only in accordance with the terms
 * of the license agreement you entered into with AmeriChoice.
 *
 *
 * DATE        PACKAGE      AUTHOR			DESCRIPTION
 * 06/11/2020  CCR-EDH      Keshavv A       Generic extract to provide based on the provided details.
 */
package com.orange.extract.main;

import java.util.logging.Level;

import com.orange.extract.utility.ReportingLogger;

public class StartProcessMain {
	static ReportingLogger logger;

	public static void main(String args[]) {

		try {
						
			int outFilename = 0;
			int logLocation = 1;
			int fileLocation = 2;
			int columnDelimeter = 3;
			int textDelimeter = 4;
			int newLineReplacer = 5;
			int dbSever = 6; // :10.237.92.18:1521:CCR
			int oracle_or_postgresql=7;
			int user = 8;
			int password = 9;
			int selectQuery = 10;
			int fromQuery = 11;
			int whereQuery = 12;
			int dbproc=13;
			int parmExcludeRef=14;
			int isHeader=15;
			
			String soutFilename = args[outFilename];
			String slogLocation = args[logLocation];
			String sfileLocation = args[fileLocation];
			String scolumnDelimeter = args[columnDelimeter];
			String stextDelimeter = args[textDelimeter];
			String snewLineReplacer = args[newLineReplacer];
			String sdbSever = args[dbSever];
			String soracle_or_postgresql = args[oracle_or_postgresql];
			String suser = args[user];
			String spassword = args[password];
			String sselectQuery = args[selectQuery];
			String sfromQuery = args[fromQuery];
			String swhereQuery = args[whereQuery];
			String sdbproc = args[dbproc];
			String sparmExcludeRef = args[parmExcludeRef];
			String sisHeader = args[isHeader];

			logger = ReportingLogger.getLogInstance(slogLocation,soutFilename);
			
			logger.log(Level.INFO, "OutFilename value received : " + soutFilename);
			logger.log(Level.INFO, "loglocation value received : " + slogLocation);
			logger.log(Level.INFO, "filelocation value received : " + sfileLocation);
			logger.log(Level.INFO, "column-delimeter value received : " + scolumnDelimeter);
			logger.log(Level.INFO, "text delimeter value received : " + stextDelimeter);
			logger.log(Level.INFO, "newLineReplacer value received : " + snewLineReplacer);
			logger.log(Level.INFO, "DB server value received : " + sdbSever);
			logger.log(Level.INFO, "DB type value received : " + soracle_or_postgresql);
			logger.log(Level.INFO, "DB user value received : " + suser);
			logger.log(Level.INFO, "DB pwd value received :");
			logger.log(Level.INFO, "Select part value received : " + sselectQuery);
			logger.log(Level.INFO, "From Part value received : " + sfromQuery);
			logger.log(Level.INFO, "where part value received : " + swhereQuery);
			logger.log(Level.INFO, "sdbproc value received : " + sdbproc);
			logger.log(Level.INFO, "sparmExcludeRef value received : " + sparmExcludeRef);
			logger.log(Level.INFO, "sisHeader value received : " + sisHeader);
			

			
			/*	
			  String soutFilename = "AccessCircuitReferences"; 
			  String slogLocation = "C:\\Users\\rtrt2974\\Desktop\\Work\\EDH\\ccr"; 
			  String sfileLocation = "C:\\Users\\rtrt2974\\Desktop\\Work\\EDH\\ccr"; 
			  String scolumnDelimeter = ","; 
			  String stextDelimeter = "\"";
			  String snewLineReplacer ="";
			  String sdbSever = "******:1521:CCR";//ip:port:service
			  String soracle_or_postgresql="ORACLE";
			  String suser = "DEX"; 
			  String spassword = ""; 
			  String sselectQuery = "*"; 
			  String sfromQuery = " ccr.access_segment_Extract "; 
			  String swhereQuery = " ";
			  //String sdbproc = "D1.ECMS_CIRCUIT.Circuit_History";
			  String sdbproc="";
			  String sparmExcludeRef = "";
			  String sisHeader ="YES";
			  logger = ReportingLogger.getLogInstance(slogLocation,soutFilename);
			 
		*/
			 if(slogLocation.trim().equals(""))
			 {
				 logger.log(Level.INFO, "Log location is required. ");
				 throw new Exception("Log location is required. ");
			 }
			
			logger.log(Level.INFO, "Intializing CCR extraction process for ..." + soutFilename);

			RStoFile rsfile = new RStoFile(soutFilename, slogLocation, sfileLocation, scolumnDelimeter, stextDelimeter,snewLineReplacer,
					sdbSever, soracle_or_postgresql,suser, spassword, sselectQuery, sfromQuery, swhereQuery,sdbproc,sparmExcludeRef,sisHeader);
			rsfile.inputValidate().QueryCheck().start();
			logger.log(Level.INFO, "Process finished.. ");

		} catch (Exception e) {
			logger.log(Level.INFO, "Process failed..Exception in main blog " + e.getMessage());
			
		}

	}
}
